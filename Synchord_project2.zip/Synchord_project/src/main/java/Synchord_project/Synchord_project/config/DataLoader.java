package Synchord_project.Synchord_project.config;
//package com.synchord.config;

import Synchord_project.Synchord_project.entity.*;
import Synchord_project.Synchord_project.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import java.time.LocalDate;
import java.util.Arrays;

@Component
@RequiredArgsConstructor
public class DataLoader implements CommandLineRunner {
    
    private final CategoryRepository categoryRepository;
    private final ProductRepository productRepository;
    private final RetailerRepository retailerRepository;
    private final ProductPriceRepository productPriceRepository;
    private final UserRepository userRepository;
    private final MarketTrendsRepository marketTrendsRepository;
    private final CompetitorAnalysisRepository competitorAnalysisRepository;
    private final PasswordEncoder passwordEncoder;
    
    @Override
    public void run(String... args) throws Exception {
        if (userRepository.count() == 0) {
            loadSampleData();
        }
        // loadMarketTrendsData(); // Uncomment if you need to load this data
    }
    
    
    private void loadSampleData() {
        // Create default users
        User buyer = new User();
        buyer.setUsername("buyer");
        buyer.setEmail("buyer@example.com");
        buyer.setPassword(passwordEncoder.encode("password123"));
        buyer.setUserType(User.UserType.BUYER);
        buyer.setFirstName("John");
        buyer.setLastName("Buyer");
        userRepository.save(buyer);

        User seller = new User();
        seller.setUsername("seller");
        seller.setEmail("seller@example.com");
        seller.setPassword(passwordEncoder.encode("password123"));
        seller.setUserType(User.UserType.SELLER);
        seller.setFirstName("Sarah");
        seller.setLastName("Seller");
        userRepository.save(seller);

        // Create categories
        Category electronics = new Category();
        electronics.setName("📱 Electronics");
        electronics.setDescription("Mobile phones, laptops, gadgets");
        categoryRepository.save(electronics);

        Category fashion = new Category();
        fashion.setName("👕 Fashion");
        fashion.setDescription("Clothing, accessories, footwear");
        categoryRepository.save(fashion);

        // Create retailers
        Retailer amazon = new Retailer();
        amazon.setName("Amazon");
        amazon.setWebsiteUrl("https://amazon.in");
        amazon.setRating(new BigDecimal("4.5"));
        amazon.setTrustScore(95);
        retailerRepository.save(amazon);

        Retailer flipkart = new Retailer();
        flipkart.setName("Flipkart");
        flipkart.setWebsiteUrl("https://flipkart.com");
        flipkart.setRating(new BigDecimal("4.6"));
        flipkart.setTrustScore(92);
        retailerRepository.save(flipkart);

        // Create sample products
        Product iphone = new Product();
        iphone.setName("Apple iPhone 15 Pro");
        iphone.setDescription("Latest iPhone with A17 Pro chip and titanium design");
        iphone.setBrand("Apple");
        iphone.setSku("IP15P256BL");
        iphone.setCategory(electronics);
        iphone.setSubcategory("Smartphones");
        iphone.setBasePrice(new BigDecimal("134900"));
        iphone.setImageUrl("https://placehold.co/600x600/3b82f6/ffffff?text=iPhone+15+Pro");
        iphone.setRating(new BigDecimal("4.8"));
        iphone.setReviewCount(1250);
        productRepository.save(iphone);

        Product samsung = new Product();
        samsung.setName("Samsung Galaxy S24 Ultra");
        samsung.setDescription("Premium Android phone with S Pen and advanced camera");
        samsung.setBrand("Samsung");
        samsung.setSku("SGS24U512BK");
        samsung.setCategory(electronics);
        samsung.setSubcategory("Smartphones");
        samsung.setBasePrice(new BigDecimal("129999"));
        samsung.setImageUrl("https://placehold.co/600x600/8b5cf6/ffffff?text=Galaxy+S24");
        samsung.setRating(new BigDecimal("4.7"));
        samsung.setReviewCount(980);
        productRepository.save(samsung);

        // Create price entries
        ProductPrice iphoneAmazon = new ProductPrice();
        iphoneAmazon.setProduct(iphone);
        iphoneAmazon.setRetailer(amazon);
        iphoneAmazon.setPrice(new BigDecimal("134900"));
        iphoneAmazon.setOriginalPrice(new BigDecimal("139900"));
        iphoneAmazon.setDiscountPercent(4);
        iphoneAmazon.setShippingCost(BigDecimal.ZERO);
        iphoneAmazon.setDeliveryTime("1-2 days");
        iphoneAmazon.setProductUrl("https://amazon.in/iphone-15-pro");
        productPriceRepository.save(iphoneAmazon);

        ProductPrice iphoneFlipkart = new ProductPrice();
        iphoneFlipkart.setProduct(iphone);
        iphoneFlipkart.setRetailer(flipkart);
        iphoneFlipkart.setPrice(new BigDecimal("133999"));
        iphoneFlipkart.setOriginalPrice(new BigDecimal("139900"));
        iphoneFlipkart.setDiscountPercent(4);
        iphoneFlipkart.setShippingCost(BigDecimal.ZERO);
        iphoneFlipkart.setDeliveryTime("2-3 days");
        iphoneFlipkart.setProductUrl("https://flipkart.com/iphone-15-pro");
        productPriceRepository.save(iphoneFlipkart);

        System.out.println("Sample data loaded successfully!");

    }    // Add this method to your existing DataLoader class
    // Add this method to your existing DataLoader class
    private void loadMarketTrendsData() {
    Category electronics = categoryRepository.findByNameContainingIgnoreCase("Electronics").stream().findFirst()
        .orElseThrow(() -> new RuntimeException("Electronics category not found"));

    // Create market trends data
    LocalDate currentDate = LocalDate.now();
    
    for (int i = 0; i < 180; i++) { // 6 months of data
        LocalDate trendDate = currentDate.minusDays(i);
        
        MarketTrends trend = new MarketTrends();
        trend.setCategory(electronics);
        trend.setAvgPrice(new BigDecimal(25000 + (Math.random() * 10000)));
        trend.setDemandIndex(50 + (int)(Math.random() * 50));
        trend.setMarketSaturation(i % 3 == 0 ? MarketTrends.SaturationLevel.HIGH : 
                                i % 3 == 1 ? MarketTrends.SaturationLevel.MEDIUM : 
                                MarketTrends.SaturationLevel.LOW);
        trend.setTrendDate(trendDate);
        trend.setTotalVolume(100000L + (long)(Math.random() * 50000));
        trend.setGrowthRate(new BigDecimal((Math.random() * 20) - 10)); // -10% to +10%
        trend.setCompetitionIndex(30 + (int)(Math.random() * 70));
        trend.setPriceElasticity(new BigDecimal(-1.0 + (Math.random() * 1.0)));
        trend.setMarketSize(new BigDecimal("1000000000")); // 1B market size
        trend.setCustomerSentiment(new BigDecimal(3.0 + (Math.random() * 2.0)));
        trend.setConfidenceScore(new BigDecimal(0.7 + (Math.random() * 0.3)));
        
        marketTrendsRepository.save(trend);
    }

    // Create competitor analysis data
    String[] competitors = {"Samsung", "Apple", "Xiaomi", "OnePlus", "Realme", "Oppo", "Vivo", "Google"};
    double[] marketShares = {28.5, 24.2, 18.7, 12.3, 8.5, 4.2, 2.8, 0.8};
    double[] growthRates = {8.5, 12.3, 15.7, 22.1, 18.9, 10.5, 7.8, 25.4};

    for (int i = 0; i < competitors.length; i++) {
        CompetitorAnalysis analysis = new CompetitorAnalysis();
        analysis.setCategory(electronics);
        analysis.setCompetitorName(competitors[i]);
        analysis.setMarketShare(new BigDecimal(marketShares[i]));
        analysis.setAvgPrice(new BigDecimal(20000 + (i * 5000)));
        analysis.setAnalysisDate(currentDate);
        analysis.setGrowthRate(new BigDecimal(growthRates[i]));
        analysis.setProductCount(50 + (i * 10));
        analysis.setCustomerRating(new BigDecimal(4.0 + (Math.random() * 1.0)));
        analysis.setReviewCount(10000 + (i * 2000));
        analysis.setMarketPresence(60 + (int)(Math.random() * 40));
        analysis.setInnovationScore(50 + (int)(Math.random() * 50));
        
        // Set market position based on market share
        if (marketShares[i] > 20) {
            analysis.setMarketPosition(CompetitorAnalysis.MarketPosition.LEADER);
        } else if (marketShares[i] > 10) {
            analysis.setMarketPosition(CompetitorAnalysis.MarketPosition.CHALLENGER);
        } else if (marketShares[i] > 5) {
            analysis.setMarketPosition(CompetitorAnalysis.MarketPosition.FOLLOWER);
        } else {
            analysis.setMarketPosition(CompetitorAnalysis.MarketPosition.NICHE);
        }
        
        // Set threat level based on growth rate
        if (growthRates[i] > 20) {
            analysis.setThreatLevel(CompetitorAnalysis.ThreatLevel.HIGH);
        } else if (growthRates[i] > 15) {
            analysis.setThreatLevel(CompetitorAnalysis.ThreatLevel.MEDIUM);
        } else {
            analysis.setThreatLevel(CompetitorAnalysis.ThreatLevel.LOW);
        }
        
        competitorAnalysisRepository.save(analysis);
    }

    System.out.println("Market trends and competitor analysis data loaded successfully!");
    }
}