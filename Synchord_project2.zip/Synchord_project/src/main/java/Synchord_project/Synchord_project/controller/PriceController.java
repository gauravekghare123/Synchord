package Synchord_project.Synchord_project.controller;

//package com.synchord.controller;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import Synchord_project.Synchord_project.entity.PriceHistory;
import Synchord_project.Synchord_project.service.PriceService;
import lombok.RequiredArgsConstructor;

@RestController
@RequestMapping("/api/prices")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class PriceController {

    private final PriceService priceService;

    @GetMapping("/history/{productId}")
    public ResponseEntity<?> getPriceHistory(
            @PathVariable Long productId,
            @RequestParam(defaultValue = "30") int days) {
        try {
            List<PriceHistory> priceHistory = priceService.getPriceHistory(productId, days);
            return ResponseEntity.ok(priceHistory);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch price history: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/trends/{productId}")
    public ResponseEntity<?> getPriceTrends(
            @PathVariable Long productId,
            @RequestParam(defaultValue = "90") int days) {
        try {
            Map<String, Object> trends = priceService.getPriceTrends(productId, days);
            return ResponseEntity.ok(trends);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch price trends: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/alerts/{productId}")
    public ResponseEntity<?> getPriceAlerts(
            @PathVariable Long productId,
            Authentication authentication) {
        try {
            String username = authentication.getName();
            var alerts = priceService.getPriceAlerts(username, productId);
            return ResponseEntity.ok(alerts);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch price alerts: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @PostMapping("/alerts/{productId}")
    public ResponseEntity<?> createPriceAlert(
            @PathVariable Long productId,
            @RequestBody Map<String, Object> alertData,
            Authentication authentication) {
        try {
            String username = authentication.getName();
            Double targetPrice = Double.parseDouble(alertData.get("targetPrice").toString());
            String alertType = (String) alertData.get("alertType");
            
            var alert = priceService.createPriceAlert(username, productId, targetPrice, alertType);
            
            return ResponseEntity.ok(alert);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to create price alert: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @DeleteMapping("/alerts/{alertId}")
    public ResponseEntity<?> deletePriceAlert(
            @PathVariable Long alertId,
            Authentication authentication) {
        try {
            String username = authentication.getName();
            priceService.deletePriceAlert(username, alertId);
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "Price alert deleted successfully");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to delete price alert: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/comparison/{productId}")
    public ResponseEntity<?> getDetailedPriceComparison(@PathVariable Long productId) {
        try {
            Map<String, Object> comparison = priceService.getDetailedPriceComparison(productId);
            return ResponseEntity.ok(comparison);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch price comparison: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/lowest/{productId}")
    public ResponseEntity<?> getLowestPrice(@PathVariable Long productId) {
        try {
            Map<String, Object> lowestPrice = priceService.getLowestPrice(productId);
            return ResponseEntity.ok(lowestPrice);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch lowest price: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/retailer/{retailerId}/products")
    public ResponseEntity<?> getRetailerProducts(
            @PathVariable Long retailerId,
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "20") int size) {
        try {
            var products = priceService.getRetailerProducts(retailerId, page, size);
            return ResponseEntity.ok(products);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch retailer products: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/analysis/{productId}")
    public ResponseEntity<?> getPriceAnalysis(@PathVariable Long productId) {
        try {
            Map<String, Object> analysis = priceService.getPriceAnalysis(productId);
            return ResponseEntity.ok(analysis);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch price analysis: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/forecast/{productId}")
    public ResponseEntity<?> getPriceForecast(
            @PathVariable Long productId,
            @RequestParam(defaultValue = "7") int days) {
        try {
            Map<String, Object> forecast = priceService.getPriceForecast(productId, days);
            return ResponseEntity.ok(forecast);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch price forecast: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/volatility/{productId}")
    public ResponseEntity<?> getPriceVolatility(
            @PathVariable Long productId,
            @RequestParam(defaultValue = "30") int days) {
        try {
            Map<String, Object> volatility = priceService.getPriceVolatility(productId, days);
            return ResponseEntity.ok(volatility);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch price volatility: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/seasonality/{productId}")
    public ResponseEntity<?> getPriceSeasonality(@PathVariable Long productId) {
        try {
            Map<String, Object> seasonality = priceService.getPriceSeasonality(productId);
            return ResponseEntity.ok(seasonality);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch price seasonality: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/best-time/{productId}")
    public ResponseEntity<?> getBestTimeToBuy(@PathVariable Long productId) {
        try {
            Map<String, Object> bestTime = priceService.getBestTimeToBuy(productId);
            return ResponseEntity.ok(bestTime);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch best time to buy: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/track/{productId}")
    public ResponseEntity<?> trackPrice(
            @PathVariable Long productId,
            Authentication authentication) {
        try {
            String username = authentication.getName();
            priceService.trackProductPrice(username, productId);
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "Price tracking started for product");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to track product price: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/tracked-products")
    public ResponseEntity<?> getTrackedProducts(Authentication authentication) {
        try {
            String username = authentication.getName();
            var trackedProducts = priceService.getTrackedProducts(username);
            return ResponseEntity.ok(trackedProducts);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch tracked products: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @DeleteMapping("/track/{productId}")
    public ResponseEntity<?> stopTracking(
            @PathVariable Long productId,
            Authentication authentication) {
        try {
            String username = authentication.getName();
            priceService.stopTrackingProduct(username, productId);
            
            Map<String, String> response = new HashMap<>();
            response.put("message", "Price tracking stopped for product");
            
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to stop tracking product: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/stats/{productId}")
    public ResponseEntity<?> getPriceStats(@PathVariable Long productId) {
        try {
            Map<String, Object> stats = priceService.getPriceStats(productId);
            return ResponseEntity.ok(stats);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to fetch price statistics: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }

    @GetMapping("/retailer-comparison")
    public ResponseEntity<?> compareRetailers(
            @RequestParam String productName,
            @RequestParam(required = false) String category) {
        try {
            Map<String, Object> comparison = priceService.compareRetailers(productName, category);
            return ResponseEntity.ok(comparison);
        } catch (Exception e) {
            Map<String, String> errorResponse = new HashMap<>();
            errorResponse.put("message", "Failed to compare retailers: " + e.getMessage());
            return ResponseEntity.badRequest().body(errorResponse);
        }
    }
}