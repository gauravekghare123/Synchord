package Synchord_project.Synchord_project.controller;


//package com.synchord.controller;

import Synchord_project.Synchord_project.dto.UserProfileResponse;
import Synchord_project.Synchord_project.entity.User;
import Synchord_project.Synchord_project.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api/user")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class UserController {

    private final UserService userService;

    @GetMapping("/profile")
    public ResponseEntity<?> getUserProfile(Authentication authentication) {
        String username = authentication.getName();
        User user = userService.getUserByUsername(username);
        
        UserProfileResponse profile = new UserProfileResponse();
        profile.setId(user.getId());
        profile.setUsername(user.getUsername());
        profile.setEmail(user.getEmail());
        profile.setUserType(user.getUserType().name());
        profile.setFirstName(user.getFirstName());
        profile.setLastName(user.getLastName());
        profile.setPhoneNumber(user.getPhoneNumber());
        profile.setProfilePictureUrl(user.getProfilePictureUrl());
        profile.setCreatedAt(user.getCreatedAt());
        profile.setLastLogin(user.getLastLogin());
        
        return ResponseEntity.ok(profile);
    }

    @PutMapping("/profile")
    public ResponseEntity<?> updateUserProfile(
            @RequestBody UserProfileResponse profileData,
            Authentication authentication) {
        String username = authentication.getName();
        User updatedUser = userService.updateUserProfile(username, profileData);
        
        UserProfileResponse response = new UserProfileResponse();
        response.setId(updatedUser.getId());
        response.setUsername(updatedUser.getUsername());
        response.setEmail(updatedUser.getEmail());
        response.setUserType(updatedUser.getUserType().name());
        response.setFirstName(updatedUser.getFirstName());
        response.setLastName(updatedUser.getLastName());
        response.setPhoneNumber(updatedUser.getPhoneNumber());
        response.setProfilePictureUrl(updatedUser.getProfilePictureUrl());
        response.setCreatedAt(updatedUser.getCreatedAt());
        response.setLastLogin(updatedUser.getLastLogin());
        
        return ResponseEntity.ok(response);
    }

    @PutMapping("/change-password")
    public ResponseEntity<?> changePassword(
            @RequestBody Map<String, String> passwordData,
            Authentication authentication) {
        String username = authentication.getName();
        String currentPassword = passwordData.get("currentPassword");
        String newPassword = passwordData.get("newPassword");
        
        userService.changePassword(username, currentPassword, newPassword);
        
        Map<String, String> response = new HashMap<>();
        response.put("message", "Password changed successfully");
        
        return ResponseEntity.ok(response);
    }

    @GetMapping("/stats")
    public ResponseEntity<?> getUserStats(Authentication authentication) {
        String username = authentication.getName();
        Map<String, Object> stats = userService.getUserStats(username);
        
        return ResponseEntity.ok(stats);
    }

    @GetMapping("/search-history")
    public ResponseEntity<?> getUserSearchHistory(Authentication authentication) {
        String username = authentication.getName();
        var searchHistory = userService.getUserSearchHistory(username);
        
        return ResponseEntity.ok(searchHistory);
    }

    @DeleteMapping("/search-history")
    public ResponseEntity<?> clearSearchHistory(Authentication authentication) {
        String username = authentication.getName();
        userService.clearSearchHistory(username);
        
        Map<String, String> response = new HashMap<>();
        response.put("message", "Search history cleared successfully");
        
        return ResponseEntity.ok(response);
    }

    @GetMapping("/product-views")
    public ResponseEntity<?> getRecentlyViewedProducts(Authentication authentication) {
        String username = authentication.getName();
        var viewedProducts = userService.getRecentlyViewedProducts(username);
        
        return ResponseEntity.ok(viewedProducts);
    }

    @PostMapping("/track-view/{productId}")
    public ResponseEntity<?> trackProductView(
            @PathVariable Long productId,
            Authentication authentication) {
        String username = authentication.getName();
        userService.trackProductView(username, productId);
        
        Map<String, String> response = new HashMap<>();
        response.put("message", "Product view tracked successfully");
        
        return ResponseEntity.ok(response);
    }

    @GetMapping("/preferences")
    public ResponseEntity<?> getUserPreferences(Authentication authentication) {
        String username = authentication.getName();
        var preferences = userService.getUserPreferences(username);
        
        return ResponseEntity.ok(preferences);
    }

    @PutMapping("/preferences")
    public ResponseEntity<?> updateUserPreferences(
            @RequestBody Map<String, Object> preferences,
            Authentication authentication) {
        String username = authentication.getName();
        var updatedPreferences = userService.updateUserPreferences(username, preferences);
        
        return ResponseEntity.ok(updatedPreferences);
    }

    @GetMapping("/notifications")
    public ResponseEntity<?> getUserNotifications(Authentication authentication) {
        String username = authentication.getName();
        var notifications = userService.getUserNotifications(username);
        
        return ResponseEntity.ok(notifications);
    }

    @PutMapping("/notifications/{notificationId}/read")
    public ResponseEntity<?> markNotificationAsRead(
            @PathVariable Long notificationId,
            Authentication authentication) {
        String username = authentication.getName();
        userService.markNotificationAsRead(username, notificationId);
        
        Map<String, String> response = new HashMap<>();
        response.put("message", "Notification marked as read");
        
        return ResponseEntity.ok(response);
    }

    @DeleteMapping("/account")
    public ResponseEntity<?> deleteAccount(Authentication authentication) {
        String username = authentication.getName();
        userService.deactivateAccount(username);
        
        Map<String, String> response = new HashMap<>();
        response.put("message", "Account deactivated successfully");
        
        return ResponseEntity.ok(response);
    }
}