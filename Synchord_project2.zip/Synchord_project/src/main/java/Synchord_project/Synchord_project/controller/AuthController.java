package Synchord_project.Synchord_project.controller;

//package com.synchord.controller;

import Synchord_project.Synchord_project.dto.AuthRequest;
import Synchord_project.Synchord_project.dto.AuthResponse;
import Synchord_project.Synchord_project.dto.SignupRequest;
import Synchord_project.Synchord_project.service.AuthService;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/auth")
@RequiredArgsConstructor
@CrossOrigin(origins = "http://localhost:3000")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/signin")
    public ResponseEntity<?> signIn(@Valid @RequestBody AuthRequest request) {
        AuthResponse response = authService.authenticateUser(request);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/signup")
    public ResponseEntity<?> signUp(@Valid @RequestBody SignupRequest request) {
        AuthResponse response = authService.registerUser(request);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/validate")
    public ResponseEntity<?> validateToken(@RequestHeader("Authorization") String token) {
        // Remove "Bearer " prefix
        if (token != null && token.startsWith("Bearer ")) {
            token = token.substring(7);
        }
        
        boolean isValid = authService.validateToken(token);
        Map<String, Object> response = new HashMap<>();
        response.put("valid", isValid);
        
        if (isValid) {
            // You can return user details here if needed
            response.put("message", "Token is valid");
        } else {
            response.put("message", "Token is invalid");
        }
        
        return ResponseEntity.ok(response);
    }

    @GetMapping("/check-username/{username}")
    public ResponseEntity<?> checkUsernameAvailability(@PathVariable String username) {
        boolean exists = authService.checkUsernameExists(username);
        Map<String, Object> response = new HashMap<>();
        response.put("available", !exists);
        response.put("username", username);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/check-email/{email}")
    public ResponseEntity<?> checkEmailAvailability(@PathVariable String email) {
        boolean exists = authService.checkEmailExists(email);
        Map<String, Object> response = new HashMap<>();
        response.put("available", !exists);
        response.put("email", email);
        return ResponseEntity.ok(response);
    }
}