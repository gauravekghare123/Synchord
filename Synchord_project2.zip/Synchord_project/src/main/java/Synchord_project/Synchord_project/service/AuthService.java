package Synchord_project.Synchord_project.service;

//package com.synchord.service;

import Synchord_project.Synchord_project.dto.AuthRequest;
import Synchord_project.Synchord_project.dto.AuthResponse;
import Synchord_project.Synchord_project.exception.AuthenticationException;
import Synchord_project.Synchord_project.exception.ResourceNotFoundException;
import Synchord_project.Synchord_project.dto.SignupRequest;
import Synchord_project.Synchord_project.entity.User;
import Synchord_project.Synchord_project.repository.UserRepository; 
import Synchord_project.Synchord_project.service.JwtService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
@RequiredArgsConstructor
public class AuthService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;
    private final JwtService jwtService;
    private final AuthenticationManager authenticationManager;

    public AuthResponse registerUser(SignupRequest request) {
        // Check if user already exists
        if (userRepository.existsByUsername(request.getUsername())) {
            throw new AuthenticationException("Username already exists");
        }
        
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new AuthenticationException("Email already exists");
        }

        // Create new user
        User user = new User();
        user.setUsername(request.getUsername());
        user.setEmail(request.getEmail());
        user.setPassword(passwordEncoder.encode(request.getPassword()));
        user.setUserType(User.UserType.valueOf(request.getRole().toUpperCase()));
        user.setIsActive(true);

        // Save user to database
        User savedUser = userRepository.save(user);

        // Generate JWT token
        String token = jwtService.generateToken(savedUser);

        return new AuthResponse(
            token,
            savedUser.getEmail(),
            savedUser.getUsername(),
            savedUser.getUserType().name()
        );
    }

    public AuthResponse authenticateUser(AuthRequest request) {
        // Authenticate user credentials
        authenticationManager.authenticate(
            new UsernamePasswordAuthenticationToken(
                request.getUsername(),
                request.getPassword()
            )
        );

        // Find user in database
        User user = userRepository.findByUsername(request.getUsername())
            .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        if (!user.getIsActive()) {
            throw new AuthenticationException("User account is deactivated");
        }

        // Generate JWT token
        String token = jwtService.generateToken(user);

        return new AuthResponse(
            token,
            user.getEmail(),
            user.getUsername(),
            user.getUserType().name()
        );
    }

    public boolean validateToken(String token) {
        try {
            String username = jwtService.extractUsername(token);
            Optional<User> user = userRepository.findByUsername(username);
            return user.isPresent() && jwtService.isTokenValid(token, user.get());
        } catch (Exception e) {
            return false;
        }
    }
    // Add these methods to the existing AuthService class
public boolean checkUsernameExists(String username) {
    return userRepository.existsByUsername(username);
}

public boolean checkEmailExists(String email) {
    return userRepository.existsByEmail(email);
}

public User getUserFromToken(String token) {
    try {
        String username = jwtService.extractUsername(token);
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
    } catch (Exception e) {
        throw new AuthenticationException("Invalid token");
    }
}
}