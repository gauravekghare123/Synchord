package Synchord_project.Synchord_project.service;
//package com.synchord.service;

import Synchord_project.Synchord_project.dto.UserProfileResponse;
import Synchord_project.Synchord_project.exception.AuthenticationException;
import Synchord_project.Synchord_project.exception.ResourceNotFoundException;
import Synchord_project.Synchord_project.entity.User;
import Synchord_project.Synchord_project.entity.UserSearch;
import Synchord_project.Synchord_project.entity.ProductView;
import Synchord_project.Synchord_project.repository.UserRepository;
import Synchord_project.Synchord_project.repository.UserSearchRepository;
import Synchord_project.Synchord_project.repository.ProductViewRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class UserService {

    private final UserRepository userRepository;
    private final UserSearchRepository userSearchRepository;
    private final ProductViewRepository productViewRepository;
    private final PasswordEncoder passwordEncoder;

    public User getUserByUsername(String username) {
        return userRepository.findByUsername(username)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + username));
    }

    public User updateUserProfile(String username, UserProfileResponse profileData) {
        User user = getUserByUsername(username);
        
        if (profileData.getFirstName() != null) {
            user.setFirstName(profileData.getFirstName());
        }
        if (profileData.getLastName() != null) {
            user.setLastName(profileData.getLastName());
        }
        if (profileData.getPhoneNumber() != null) {
            user.setPhoneNumber(profileData.getPhoneNumber());
        }
        if (profileData.getProfilePictureUrl() != null) {
            user.setProfilePictureUrl(profileData.getProfilePictureUrl());
        }
        
        return userRepository.save(user);
    }

    public void changePassword(String username, String currentPassword, String newPassword) {
        User user = getUserByUsername(username);
        
        if (!passwordEncoder.matches(currentPassword, user.getPassword())) {
            throw new AuthenticationException("Current password is incorrect");
        }
        
        if (newPassword.length() < 6) {
            throw new AuthenticationException("New password must be at least 6 characters long");
        }
        
        user.setPassword(passwordEncoder.encode(newPassword));
        userRepository.save(user);
    }

    public Map<String, Object> getUserStats(String username) {
        User user = getUserByUsername(username);
        
        // Get search count
        long searchCount = userSearchRepository.countByUserId(user.getId());
        
        // Get product views count
        long viewCount = productViewRepository.countByUserId(user.getId());
        
        // Get recent activity
        List<UserSearch> recentSearches = userSearchRepository.findTop5ByUserIdOrderBySearchedAtDesc(user.getId());
        
        Map<String, Object> stats = new HashMap<>();
        stats.put("totalSearches", searchCount);
        stats.put("totalProductViews", viewCount);
        stats.put("memberSince", user.getCreatedAt());
        stats.put("lastLogin", user.getLastLogin());
        stats.put("recentSearches", recentSearches.stream()
                .map(search -> Map.of(
                        "query", search.getSearchQuery(),
                        "date", search.getSearchedAt(),
                        "results", search.getSearchResultsCount()
                ))
                .collect(Collectors.toList()));
        
        return stats;
    }

    public List<Map<String, Object>> getUserSearchHistory(String username) {
        User user = getUserByUsername(username);
        
        return userSearchRepository.findByUserIdOrderBySearchedAtDesc(user.getId())
                .stream()
                .map(search -> Map.of(
                        "id", search.getId(),
                        "query", search.getSearchQuery(),
                        "results", search.getSearchResultsCount(),
                        "date", search.getSearchedAt()
                ))
                .collect(Collectors.toList());
    }

    public void clearSearchHistory(String username) {
        User user = getUserByUsername(username);
        userSearchRepository.deleteByUserId(user.getId());
    }

    public List<Map<String, Object>> getRecentlyViewedProducts(String username) {
        User user = getUserByUsername(username);
        
        return productViewRepository.findTop10ByUserIdOrderByViewedAtDesc(user.getId())
                .stream()
                .map(view -> {
                    var product = view.getProduct();
                    return Map.of(
                            "id", product.getId(),
                            "name", product.getName(),
                            "imageUrl", product.getImageUrl(),
                            "price", product.getBasePrice(),
                            "brand", product.getBrand(),
                            "viewedAt", view.getViewedAt()
                    );
                })
                .collect(Collectors.toList());
    }

    public void trackProductView(String username, Long productId) {
        User user = getUserByUsername(username);
        
        // In a real application, you would fetch the product from repository
        // For now, we'll create a simple tracking record
        ProductView view = new ProductView();
        view.setUser(user);
        view.setProductId(productId); // This would be a Product entity in real implementation
        view.setViewedAt(LocalDateTime.now());
        view.setSessionId("session_" + System.currentTimeMillis()); // Simplified session ID
        
        productViewRepository.save(view);
    }

    public Map<String, Object> getUserPreferences(String username) {
        User user = getUserByUsername(username);
        
        // Default preferences
        Map<String, Object> preferences = new HashMap<>();
        preferences.put("theme", "light");
        preferences.put("notifications", true);
        preferences.put("emailAlerts", true);
        preferences.put("priceDropAlerts", true);
        preferences.put("currency", "INR");
        preferences.put("language", "en");
        
        // In a real application, you would store and retrieve these from a database
        return preferences;
    }

    public Map<String, Object> updateUserPreferences(String username, Map<String, Object> newPreferences) {
        User user = getUserByUsername(username);
        
        // In a real application, you would validate and store these preferences
        // For now, we'll just return the updated preferences
        Map<String, Object> updatedPreferences = new HashMap<>();
        updatedPreferences.put("theme", newPreferences.getOrDefault("theme", "light"));
        updatedPreferences.put("notifications", newPreferences.getOrDefault("notifications", true));
        updatedPreferences.put("emailAlerts", newPreferences.getOrDefault("emailAlerts", true));
        updatedPreferences.put("priceDropAlerts", newPreferences.getOrDefault("priceDropAlerts", true));
        updatedPreferences.put("currency", newPreferences.getOrDefault("currency", "INR"));
        updatedPreferences.put("language", newPreferences.getOrDefault("language", "en"));
        updatedPreferences.put("updatedAt", LocalDateTime.now());
        
        return updatedPreferences;
    }

    public List<Map<String, Object>> getUserNotifications(String username) {
        User user = getUserByUsername(username);
        
        // Sample notifications - in real app, these would come from database
        return List.of(
                Map.of(
                        "id", 1L,
                        "type", "PRICE_DROP",
                        "title", "Price drop alert",
                        "message", "iPhone 15 Pro price dropped by ₹5,000",
                        "read", false,
                        "createdAt", LocalDateTime.now().minusHours(2)
                ),
                Map.of(
                        "id", 2L,
                        "type", "SYSTEM",
                        "title", "Welcome to Synchord",
                        "message", "Thank you for joining our platform",
                        "read", true,
                        "createdAt", LocalDateTime.now().minusDays(1)
                )
        );
    }

    public void markNotificationAsRead(String username, Long notificationId) {
        // In a real application, you would update the notification status in database
        System.out.println("Marking notification " + notificationId + " as read for user " + username);
    }

    public void deactivateAccount(String username) {
        User user = getUserByUsername(username);
        user.setIsActive(false);
        userRepository.save(user);
        
        // Also clear user data (in a real application, you might want to anonymize instead of delete)
        userSearchRepository.deleteByUserId(user.getId());
        productViewRepository.deleteByUserId(user.getId());
    }

    public void recordSearch(String username, String query, int resultsCount) {
        User user = getUserByUsername(username);
        
        UserSearch search = new UserSearch();
        search.setUser(user);
        search.setSearchQuery(query);
        search.setSearchResultsCount(resultsCount);
        search.setSearchedAt(LocalDateTime.now());
        
        userSearchRepository.save(search);
    }
}