
package Synchord_project.Synchord_project.service;

import Synchord_project.Synchord_project.dto.CategoryResponse;
import Synchord_project.Synchord_project.dto.ProductResponse;
import Synchord_project.Synchord_project.exception.ResourceNotFoundException;
import Synchord_project.Synchord_project.entity.Product;
import Synchord_project.Synchord_project.repository.ProductRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class ProductService {

    private final ProductRepository productRepository;

    @Transactional(readOnly = true)
    public Page<ProductResponse> searchProducts(String query, Pageable pageable) {
        return productRepository.searchProducts(query, pageable)
                .map(this::convertToResponse);
    }

    @Transactional(readOnly = true)
    public Page<ProductResponse> getAllProducts(Pageable pageable) {
        return productRepository.findByIsActiveTrue(pageable)
                .map(this::convertToResponse);
    }

    @Transactional(readOnly = true)
    public ProductResponse getProductById(Long id) {
        Product product = productRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Product not found with id: " + id));
        return convertToResponse(product);
    }

    private ProductResponse convertToResponse(Product product) {
        ProductResponse response = new ProductResponse();
        response.setId(product.getId());
        response.setName(product.getName());
        response.setDescription(product.getDescription());
        response.setBrand(product.getBrand());
        response.setSku(product.getSku());
        if (product.getCategory() != null) {
            CategoryResponse categoryResponse = new CategoryResponse();
            categoryResponse.setId(product.getCategory().getId());
            categoryResponse.setName(product.getCategory().getName());
            response.setCategory(categoryResponse);
        }
        response.setSubcategory(product.getSubcategory());
        response.setBasePrice(product.getBasePrice() != null ? product.getBasePrice().doubleValue() : null);
        response.setImageUrl(product.getImageUrl());
        response.setRating(product.getRating() != null ? product.getRating().doubleValue() : null);
        response.setReviewCount(product.getReviewCount());
        return response;
    }
}
