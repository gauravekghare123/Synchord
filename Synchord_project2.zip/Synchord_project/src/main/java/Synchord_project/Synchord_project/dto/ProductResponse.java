package Synchord_project.Synchord_project.dto;

import lombok.Data;

@Data
public class ProductResponse {
    private Long id;
    private String name;
    private String description;
    private String brand;
    private String sku;
    private CategoryResponse category;
    private String subcategory;
    private Double basePrice;
    private String imageUrl;
    private Double rating;
    private Integer reviewCount;
}
