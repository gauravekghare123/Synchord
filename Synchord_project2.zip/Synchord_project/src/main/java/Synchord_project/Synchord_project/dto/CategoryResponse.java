
package Synchord_project.Synchord_project.dto;

import lombok.Data;

@Data
public class CategoryResponse {
    private Long id;
    private String name;
}
