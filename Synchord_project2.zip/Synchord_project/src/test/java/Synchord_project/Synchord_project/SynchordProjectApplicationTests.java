package Synchord_project.Synchord_project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SynchordProjectApplicationTests {

	@Test
	void contextLoads() {
	}

}
