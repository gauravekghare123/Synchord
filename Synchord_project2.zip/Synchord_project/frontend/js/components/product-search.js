import { ProductAPI } from '../api/product-api.js';

export class ProductSearch {
    constructor() {
        this.productAPI = new ProductAPI();
        this.searchResultsContainer = document.getElementById('search-results-container');
    }

    init() {
        this.setupEventListeners();
    }

    setupEventListeners() {
        // Real-time search debouncing
        let searchTimeout;
        document.getElementById('product-search-input')?.addEventListener('input', (e) => {
            clearTimeout(searchTimeout);
            const query = e.target.value.trim();
            
            if (query.length >= 2) {
                searchTimeout = setTimeout(() => {
                    this.search(query);
                }, 500);
            } else if (query.length === 0) {
                this.clearResults();
            }
        });
    }

    async search(query) {
        try {
            this.showLoading();
            const response = await this.productAPI.searchProducts(query);
            this.displayResults(response.content, query);
        } catch (error) {
            this.showError(error.message, query);
        }
    }

    showLoading() {
        this.searchResultsContainer.innerHTML = `
            <div class="text-center py-12">
                <div class="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                <p class="text-lg">Searching products...</p>
            </div>
        `;
    }

    displayResults(products, query) {
        if (!products || products.length === 0) {
            this.showNoResults(query);
            return;
        }

        this.searchResultsContainer.innerHTML = `
            <div class="mb-8">
                <h2 class="text-2xl font-bold">Search Results for "${query}"</h2>
                <p class="text-gray-600">Found ${products.length} products</p>
            </div>
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                ${products.map((product, index) => this.createProductCard(product, index)).join('')}
            </div>
        `;

        // Add click event listeners to product cards
        products.forEach((product, index) => {
            const card = this.searchResultsContainer.querySelector(`[data-product-id="${product.id}"]`);
            if (card) {
                card.addEventListener('click', () => {
                    if (window.app && window.app.buyerView) {
                        window.app.buyerView.showProductDetails(product);
                    }
                });
            }
        });
    }

    createProductCard(product, index) {
        const imageUrl = product.imageUrl || `https://placehold.co/400x400/e2e8f0/64748b?text=${encodeURIComponent(product.name)}`;
        
        return `
            <div class="product-card bg-white rounded-lg shadow-md overflow-hidden cursor-pointer transform hover:scale-105 transition-transform duration-200 fade-in-up"
                 data-product-id="${product.id}"
                 style="animation-delay: ${index * 100}ms">
                <div class="relative">
                    <img src="${imageUrl}" alt="${product.name}" 
                         class="w-full h-48 object-cover"
                         onerror="this.src='https://placehold.co/400x400/e2e8f0/64748b?text=Product+Image'">
                    <div class="absolute top-2 right-2 bg-blue-600 text-white px-2 py-1 rounded-full text-xs">
                        ${product.category}
                    </div>
                </div>
                <div class="p-4">
                    <h3 class="font-semibold text-lg mb-2 line-clamp-2">${product.name}</h3>
                    <p class="text-gray-600 text-sm mb-3 line-clamp-2">${product.description}</p>
                    <div class="flex items-center justify-between">
                        <div>
                            <p class="text-2xl font-bold text-green-600">₹${product.basePrice ? product.basePrice.toLocaleString() : 'N/A'}</p>
                            <p class="text-sm text-gray-500">by ${product.brand}</p>
                        </div>
                        <div class="flex items-center">
                            <span class="text-yellow-400">★</span>
                            <span class="ml-1 text-sm">${product.rating}</span>
                        </div>
                    </div>
                </div>
            </div>
        `;
    }

    showNoResults(query) {
        this.searchResultsContainer.innerHTML = `
            <div class="text-center py-12">
                <div class="text-6xl mb-4">🔍</div>
                <h3 class="text-xl font-semibold mb-2">No products found</h3>
                <p class="text-gray-600 mb-4">We couldn't find any products matching "${query}"</p>
                <button onclick="window.app.buyerView.showSearchPage()" 
                        class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors">
                    Back to Search
                </button>
            </div>
        `;
    }

    showError(message, query) {
        this.searchResultsContainer.innerHTML = `
            <div class="text-center py-12">
                <div class="text-6xl mb-4 text-red-500">⚠️</div>
                <h3 class="text-xl font-semibold mb-2 text-red-600">Search Failed</h3>
                <p class="text-gray-600 mb-4">${message}</p>
                <button onclick="window.app.productSearch.search('${query}')" 
                        class="bg-blue-600 text-white px-6 py-2 rounded-lg hover:bg-blue-700 transition-colors mr-2">
                    Try Again
                </button>
                <button onclick="window.app.buyerView.showSearchPage()" 
                        class="bg-gray-600 text-white px-6 py-2 rounded-lg hover:bg-gray-700 transition-colors">
                    Back to Search
                </button>
            </div>
        `;
    }

    clearResults() {
        this.searchResultsContainer.innerHTML = '';
    }
}